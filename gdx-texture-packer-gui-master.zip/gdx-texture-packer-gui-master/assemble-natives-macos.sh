#!/bin/bash
# Should executed on MacOS only.
./gradlew jnigen jnigenBuildMacOsX64 jnigenJarNativesDesktop
