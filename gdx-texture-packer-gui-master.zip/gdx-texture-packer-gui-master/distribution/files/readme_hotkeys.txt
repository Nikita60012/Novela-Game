You can define/override you own keyboard shortcuts for some actions.
For the details look at the default hotkey configuration file.
https://github.com/crashinvaders/gdx-texture-packer-gui/blob/master/assets/hotkeys_default.txt