---
name: Crash report
about: Create a crash report to help us track the bug
title: Crash report
labels: crash report
assignees: ''

---

> Please paste the crash log in here (already in your clipboard) and, if possible, provide any information that may help to reproduce the issue.
