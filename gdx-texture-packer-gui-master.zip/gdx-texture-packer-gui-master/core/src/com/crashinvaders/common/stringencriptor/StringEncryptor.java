package com.crashinvaders.common.stringencriptor;

public interface StringEncryptor {
    String encrypt(String value);
    String decrypt(String value);
}
