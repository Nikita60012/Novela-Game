package com.crashinvaders.texturepackergui.utils.packprocessing;

public interface PackProcessor {
    void processPackage(PackProcessingNode node) throws Exception;
}
