package com.crashinvaders.texturepackergui;

import java.io.File;

public class AppParams {
    public File startupProject = null;
    public boolean debug = false;
}
