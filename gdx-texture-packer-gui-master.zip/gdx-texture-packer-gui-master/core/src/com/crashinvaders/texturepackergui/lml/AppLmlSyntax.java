package com.crashinvaders.texturepackergui.lml;

import com.crashinvaders.common.scene2d.lml.AnimatedImage;
import com.crashinvaders.common.scene2d.lml.attributes.HorizontalGroupExpandLmlAttribute;
import com.crashinvaders.common.scene2d.lml.attributes.VerticalGroupExpandLmlAttribute;
import com.crashinvaders.common.scene2d.lml.tags.PatchedVisTextFieldLmlTag;
import com.crashinvaders.texturepackergui.lml.attributes.*;
import com.crashinvaders.texturepackergui.lml.attributes.seekbar.*;
import com.crashinvaders.texturepackergui.lml.tags.*;
import com.crashinvaders.texturepackergui.lml.tags.seekbar.FloatSeekBarLmlTag;
import com.crashinvaders.texturepackergui.lml.tags.seekbar.IntSeekBarLmlTag;
import com.crashinvaders.texturepackergui.views.ExpandEditTextButton;
import com.crashinvaders.texturepackergui.views.canvas.PagePreviewCanvas;
import com.github.czyzby.lml.parser.impl.attribute.container.ContainerFillLmlAttribute;
import com.github.czyzby.lml.parser.impl.attribute.container.ContainerFillXLmlAttribute;
import com.github.czyzby.lml.parser.impl.attribute.container.ContainerFillYLmlAttribute;
import com.github.czyzby.lml.vis.parser.impl.VisLmlSyntax;

public class AppLmlSyntax extends VisLmlSyntax {

    @Override
    protected void registerActorTags() {
        super.registerActorTags();

        addTagProvider(new GroupLmlTag.TagProvider(), "group");
        addTagProvider(new PagePreviewCanvas.CanvasLmlTagProvider(), "canvas");
        addTagProvider(new FixedIntSpinnerLmlTagProvider(), "intSpinner");
        addTagProvider(new FixedFloatSpinnerLmlTagProvider(), "floatSpinner");
        addTagProvider(new ShrinkContainerLmlTag.TagProvider(), "shrinkContainer");
        addTagProvider(new ExpandEditTextButton.TagProvider(), "expandEditTextButton");
        addTagProvider(new BusyBarLmlTag.TagProvider(), "busybar");
        addTagProvider(new TransformScalableWrapperLmlTag.TagProvider(), "transformScalable");
        addTagProvider(new ScalarScalableWrapperLmlTag.TagProvider(), "scalarScalable");
        addTagProvider(new AnimatedImage.LmlTag.Provider(), "animatedImage");
        addTagProvider(new PatchedVisTextFieldLmlTag.Provider(), "textField", "visTextField");
        addTagProvider(new IntSeekBarLmlTag.Provider(), "intSeekBar");
        addTagProvider(new FloatSeekBarLmlTag.Provider(), "floatSeekBar");
        addTagProvider(new MenuBarXLmlTag.Provider(), "menuBar");
    }

    @Override
    protected void registerAttributes() {
        super.registerAttributes();

        registerSeekBarAttributes();
    }

    @Override
    protected void registerBuildingAttributes() {
        super.registerBuildingAttributes();

        // IntSeekBarLmlBuilder:
        addBuildingAttributeProcessor(new IntSeekBarMaxLmlAttribute(), "max");
        addBuildingAttributeProcessor(new IntSeekBarMinLmlAttribute(), "min");
        addBuildingAttributeProcessor(new IntSeekBarStepLmlAttribute(), "step");
        addBuildingAttributeProcessor(new IntSeekBarValueLmlAttribute(), "value");

        // FloatSeekBarLmlBuilder:
        addBuildingAttributeProcessor(new FloatSeekBarMaxLmlAttribute(), "max");
        addBuildingAttributeProcessor(new FloatSeekBarMinLmlAttribute(), "min");
        addBuildingAttributeProcessor(new FloatSeekBarStepLmlAttribute(), "step");
        addBuildingAttributeProcessor(new FloatSeekBarValueLmlAttribute(), "value");
        addBuildingAttributeProcessor(new FloatSeekBarPrecisionLmlAttribute(), "precision");
    }

    @Override
    protected void registerCommonAttributes() {
        super.registerCommonAttributes();

        addAttributeProcessor(new PatchedOnClickLmlAttribute(), "onClick", "click");
        addAttributeProcessor(new OnRightClickLmlAttribute(), "onRightClick", "rightClick");
        addAttributeProcessor(new OnDoubleClickLmlAttribute(), "onDoubleClick", "doubleClick");
        addAttributeProcessor(new OnTouchUpLmlAttribute(), "onTouchUp", "touchUp");
        addAttributeProcessor(new ScrollFocusCaptureLmlAttribute(), "scrollCapture");
        addAttributeProcessor(new TimeThresholdChangeListenerLmlAttribute(), "delayedChange", "delayedOnChange", "timeThresholdChange");
        addAttributeProcessor(new TooltipLmlAttribute(), "visTooltip", "tooltip");
        addAttributeProcessor(new KeyboardFocusChangedLmlAttribute(), "keyboardFocus");
        addAttributeProcessor(new OriginLmlAttribute(), "origin");
        addAttributeProcessor(new AdvancedColorLmLAttribute(), "color");
        //TODO: Remove this attribute as it is now replaced with AdvancedColorLmlAttribute
        addAttributeProcessor(new HexColorLmlAttribute(), "hexColor");
        addAttributeProcessor(new OnBackPressedLmlAttribute(), "back", "onBack", "onEscape");
        addAttributeProcessor(new DelegateInputEventsLmlAttribute(), "delegateInput");
        addAttributeProcessor(new ConsumeInputLmlAttribute(), "consumeInput");
    }

    @Override
    protected void registerImageAttributes() {
        super.registerImageAttributes();

        addAttributeProcessor(new ImageTiledLmlAttribute(), "tiled");
    }

    @Override
    protected void registerTableAttributes() {
        super.registerTableAttributes();

        addAttributeProcessor(new TableTiledBackgroundLmlAttribute(), "bgTiled", "backgroundTiled");
    }

    @Override
    protected void registerContainerAttributes() {
        super.registerContainerAttributes();

        addAttributeProcessor(new ContainerPadLmlAttribute.Top(), "containerPadTop");
        addAttributeProcessor(new ContainerPadLmlAttribute.Left(), "containerPadLeft");
        addAttributeProcessor(new ContainerPadLmlAttribute.Bottom(), "containerPadBottom");
        addAttributeProcessor(new ContainerPadLmlAttribute.Right(), "containerPadRight");
        addAttributeProcessor(new ContainerPadLmlAttribute.All(), "containerPad");
        addAttributeProcessor(new ContainerFillLmlAttribute(), "containerFill");
        addAttributeProcessor(new ContainerFillXLmlAttribute(), "containerFillX");
        addAttributeProcessor(new ContainerFillYLmlAttribute(), "containerFillY");
    }

    @Override
    protected void registerMenuAttributes() {
        super.registerMenuAttributes();

        addAttributeProcessor(new ShortcutOnChangeLmlAttribute(), "onchange", "change");
        addAttributeProcessor(new MenuItemFillImageLmlAttribute(), "fillImage");
    }

    @Override
    protected void registerLabelAttributes() {
        super.registerLabelAttributes();

        addAttributeProcessor(new LabelFontScaleLmlAttribute(), "fontScale");
    }

    @Override
    protected void registerSpinnerAttributes() {
        super.registerSpinnerAttributes();

        addAttributeProcessor(new SpinnerSelectAllOnFocusLmlAttribute(), "selectAllOnFocus");
    }

    @Override
    protected void registerLinkLabelAttributes() {
        super.registerLinkLabelAttributes();

        addAttributeProcessor(new LinkLabelSetEmptyListenerLmlAttribute(), "setEmptyListener");
    }

    @Override
    protected void registerListViewAttributes() {
        super.registerListViewAttributes();

        addAttributeProcessor(new ListViewOnClickLmlAttribute(), "listViewOnClick");
    }

    @Override
    protected void registerVerticalGroupAttributes() {
        super.registerVerticalGroupAttributes();

        addAttributeProcessor(new VerticalGroupExpandLmlAttribute(), "groupExpand");
    }

    @Override
    protected void registerHorizontalGroupAttributes() {
        super.registerHorizontalGroupAttributes();

        addAttributeProcessor(new HorizontalGroupExpandLmlAttribute(), "groupExpand");
    }

    protected void registerSeekBarAttributes() {
        addAttributeProcessor(new SeekBarChangePolicyLmlAttribute(), "changePolicy");
    }
}
