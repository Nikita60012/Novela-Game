package com.crashinvaders.texturepackergui.controllers;

import com.github.czyzby.autumn.mvc.stereotype.ViewDialog;

@ViewDialog(id = "dialog_about", value = "lml/dialogAbout.lml")
public class AboutDialogController {
}
