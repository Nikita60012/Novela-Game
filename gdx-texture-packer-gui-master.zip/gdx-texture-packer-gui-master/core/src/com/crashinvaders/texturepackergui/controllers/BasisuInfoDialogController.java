package com.crashinvaders.texturepackergui.controllers;

import com.github.czyzby.autumn.mvc.stereotype.ViewDialog;

@ViewDialog(id = "dialog_basisu_info", value = "lml/dialogBasisuInfo.lml")
public class BasisuInfoDialogController {
}
