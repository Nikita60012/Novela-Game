package com.crashinvaders.texturepackergui.controllers.settings;

import com.badlogic.gdx.scenes.scene2d.ui.Container;

public interface SectionContentController {
    void show(Container parent);
    void hide();
}
