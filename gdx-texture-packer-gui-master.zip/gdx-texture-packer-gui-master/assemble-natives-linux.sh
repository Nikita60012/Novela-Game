#!/bin/bash
./gradlew jnigen jnigenBuildLinux jnigenBuildLinux64 jnigenJarNativesDesktop
